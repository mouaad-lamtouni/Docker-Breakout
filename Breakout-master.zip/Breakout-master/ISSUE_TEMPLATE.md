Please look over the code of conduct before creating an issue.

Make sure that your issue is in accordance with the following rules. Put in X between the ones that our.


- [ ] I have looked over the code of conduct, and the content of the issue is inline with it.
- [ ] I have checked if this bug and/or feature has been already created an issue of.
